class MissingEnvironmentVariable(Exception):
    pass