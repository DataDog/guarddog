class Detector:
    def __init__(self) -> None:
        pass
    
    def detect(self, package_info) -> list | bool:
        pass